param([int]$TargetPid,[string]$ReadyFile)
$ErrorActionPreference='Stop'
$heldHost=[Diagnostics.Process]::GetProcessById($TargetPid)
$null=$heldHost.Handle
$created=$heldHost.StartTime.ToUniversalTime().ToString('o')
$executable=$heldHost.MainModule.FileName
@{pid=$heldHost.Id;creationTime=$created;executable=$executable} | ConvertTo-Json -Compress | Set-Content -LiteralPath $ReadyFile
if (-not $heldHost.WaitForExit(150000)) { throw 'Owned Host did not close within observation budget' }
@{pid=$heldHost.Id;creationTime=$created;executable=$executable;exitCode=$heldHost.ExitCode} | ConvertTo-Json -Compress
$heldHost.Dispose()
